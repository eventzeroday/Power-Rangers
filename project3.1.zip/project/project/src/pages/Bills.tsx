// ---------------- FULL UPDATED Bills.tsx --------------------
import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import { useAuth } from "../contexts/AuthContext";
import {
  Plus, X, Edit, Trash2, CheckCircle, Clock, AlertCircle
} from "lucide-react";
import { extractBillData } from "../utils/ocr";

interface Bill {
  id: string;
  bill_name: string;
  amount: number;
  due_date: string;
  status: "paid" | "pending" | "overdue";
  category: string;
  recurring: boolean;
  created_at: string;
}

interface BillFile {
  id: string;
  bill_id: string;
  file_url: string;
}

// ---------------------------------------------------------

export function Bills() {
  const { user } = useAuth();
  const [bills, setBills] = useState<Bill[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingBill, setEditingBill] = useState<Bill | null>(null);

  const [formData, setFormData] = useState({
    name: "",
    amount: "",
    due_date: "",
    status: "pending" as "paid" | "pending" | "overdue",
    category: "utilities",
    recurring: false,
  });

  // --- NEW STATE FOR UPLOAD + OCR -------------------------
  const [uploadedFileUrl, setUploadedFileUrl] = useState<string | null>(null);
  const [extractedData, setExtractedData] = useState<any>(null);

  // ---------------------------------------------------------

  useEffect(() => {
    if (user) loadBills();
  }, [user]);

  const loadBills = async () => {
    try {
      const { data, error } = await supabase
        .from("bills")
        .select("*")
        .eq("user_id", user!.id)
        .order("due_date", { ascending: true });

      if (error) throw error;

      const billsMapped = (data || []).map((bill) => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (bill.status !== "paid" && new Date(bill.due_date) < today) {
          bill.status = "overdue";
        }
        return bill;
      });

      setBills(billsMapped);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // ---------------------------------------------------------
  // FILE UPLOAD + OCR EXTRACTION
  async function onFileUpload(event: any) {
    const file = event.target.files[0];
    if (!file) return;

    // Upload image to storage
    const filename = `${user!.id}/${Date.now()}-${file.name}`;
    const { data, error } = await supabase.storage.from("bills").upload(filename, file);

    if (error) {
      alert("❌ Upload failed");
      return;
    }

    const fileUrl = supabase.storage.from("bills").getPublicUrl(data.path).data.publicUrl;
    setUploadedFileUrl(fileUrl);

    // OCR extract
    const result: any = await extractBillData(file);
    setExtractedData({ ...result, preview: fileUrl });

    // Autofill input form
    setFormData({
      name: result.bill_name ?? "",
      amount: result.amount ?? "",
      due_date: result.due_date ?? "",
      status: result.status ?? "pending",
      category: result.category ?? "other",
      recurring: false,
    });
  }

  // ---------------------------------------------------------
  // ADD / UPDATE BILL
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      let createdBill: Bill | null = null;

      // UPDATE BILL
      if (editingBill) {
        const { data, error } = await supabase
          .from("bills")
          .update({
            bill_name: formData.name,
            amount: Number(formData.amount),
            due_date: formData.due_date,
            status: formData.status,
            category: formData.category,
            recurring: formData.recurring,
          })
          .eq("id", editingBill.id)
          .select()
          .single();

        if (error) throw error;
        createdBill = data;
      }

      // INSERT BILL
      if (!editingBill) {
        const { data, error } = await supabase
          .from("bills")
          .insert({
            user_id: user!.id,
            bill_name: formData.name,
            amount: Number(formData.amount),
            due_date: formData.due_date,
            status: formData.status,
            category: formData.category,
            recurring: formData.recurring,
          })
          .select()
          .single();

        if (error) throw error;
        createdBill = data;
      }

      // SAVE IMAGE REFERENCE
      if (uploadedFileUrl && createdBill) {
        await supabase.from("bill_files").insert({
          bill_id: createdBill.id,
          file_url: uploadedFileUrl,
        });
      }

      // reset modal
      resetForm();
      setShowModal(false);
      setEditingBill(null);
      loadBills();
    } catch (error) {
      console.error("Save failed:", error);
      alert("⚠ Failed to save — check console.");
    }
  };

  // ---------------------------------------------------------
  const deleteBill = async (id: string) => {
    if (!confirm("Delete this bill?")) return;
    await supabase.from("bills").delete().eq("id", id);
    loadBills();
  };

  const markAsPaid = async (bill: Bill) => {
    await supabase.from("bills").update({ status: "paid" }).eq("id", bill.id);
    loadBills();
  };

  const resetForm = () => {
    setFormData({
      name: "",
      amount: "",
      due_date: "",
      status: "pending",
      category: "utilities",
      recurring: false,
    });
    setUploadedFileUrl(null);
    setExtractedData(null);
  };

  const openEditModal = (bill: Bill) => {
    setEditingBill(bill);
    setFormData({
      name: bill.bill_name,
      amount: bill.amount.toString(),
      due_date: bill.due_date,
      status: bill.status,
      category: bill.category,
      recurring: bill.recurring,
    });
    setShowModal(true);
  };

  // ---------------------------------------------------------
  const pendingBills = bills.filter(b => b.status === "pending");
  const overdueBills = bills.filter(b => b.status === "overdue");
  const paidBills = bills.filter(b => b.status === "paid");

  if (loading) return <div className="text-center p-8">Loading...</div>;

  // ---------------------------------------------------------
  return (
    <div className="p-8">
      {/* HEADER */}
      <div className="flex justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Bills & Receipts</h1>
          <p className="text-gray-600">Track & upload your bills</p>
        </div>
        <button
          onClick={() => { resetForm(); setEditingBill(null); setShowModal(true); }}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg flex gap-2 items-center"
        >
          <Plus size={20} /> Add Bill
        </button>
      </div>

      {/* LIST */}
      <BillSection title="Overdue Bills" color="red" bills={overdueBills}
        openEditModal={openEditModal} deleteBill={deleteBill} markAsPaid={markAsPaid} />

      <BillSection title="Pending Bills" color="amber" bills={pendingBills}
        openEditModal={openEditModal} deleteBill={deleteBill} markAsPaid={markAsPaid} />

      <BillSection title="Paid Bills" color="green" bills={paidBills}
        openEditModal={openEditModal} deleteBill={deleteBill} markAsPaid={markAsPaid} />

      {/* MODAL */}
      {showModal && (
        <BillModal
          editingBill={editingBill}
          formData={formData}
          setFormData={setFormData}
          extractedData={extractedData}
          onFileUpload={onFileUpload}
          handleSubmit={handleSubmit}
          close={() => { resetForm(); setShowModal(false); }}
        />
      )}
    </div>
  );
}

// ---------------------------------------------------------
// BILL CARD + IMAGE PREVIEW
function BillSection({ title, color, bills, openEditModal, deleteBill, markAsPaid }: any) {
  if (!bills.length) return null;

  return (
    <div className="mb-6">
      <h3 className={`font-semibold text-${color}-600 mb-2 text-xl`}>{title}</h3>
      <div className="grid md:grid-cols-3 gap-4">
        {bills.map((bill: Bill) => <BillCard key={bill.id} bill={bill}
          onEdit={openEditModal} onDelete={deleteBill} onMarkPaid={markAsPaid} />)}
      </div>
    </div>
  );
}

function BillCard({ bill, onEdit, onDelete, onMarkPaid }: any) {
  const [images, setImages] = useState<BillFile[]>([]);

  useEffect(() => {
    supabase.from("bill_files").select("*").eq("bill_id", bill.id)
      .then(({ data }) => setImages(data || []));
  }, []);

  return (
    <div className="border p-4 rounded-xl shadow-sm bg-white">
      {images[0] && <img src={images[0].file_url} className="rounded-lg mb-3 max-h-40 w-full object-cover" />}
      <h4 className="font-bold">{bill.bill_name}</h4>
      <p>₹ {bill.amount}</p>
      <p>{bill.due_date}</p>
      <div className="flex gap-2 mt-3">
        {bill.status !== "paid" && (
          <button onClick={() => onMarkPaid(bill)} className="bg-green-600 text-white px-3 py-1 rounded-lg flex-1">
            Mark Paid
          </button>
        )}
        <button onClick={() => onEdit(bill)} className="bg-blue-600 text-white px-3 py-1 rounded-lg">
          <Edit size={16} />
        </button>
        <button onClick={() => onDelete(bill.id)} className="bg-red-600 text-white px-3 py-1 rounded-lg">
          <Trash2 size={16} />
        </button>
      </div>
    </div>
  );
}

// ---------------------------------------------------------
// UPLOAD + OCR MODAL
function BillModal({ editingBill, formData, setFormData, handleSubmit, close, onFileUpload, extractedData }: any) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex justify-center items-center p-6">
      <div className="bg-white rounded-xl w-full max-w-md shadow-lg">
        <div className="p-4 flex justify-between items-center border-b">
          <h2 className="text-xl font-bold">{editingBill ? "Edit Bill" : "Add Bill"}</h2>
          <button onClick={close}><X size={24} /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">

          {/* UPLOAD IMAGE */}
          <label className="block text-sm font-medium">Upload Bill Image</label>
          <input type="file" accept="image/*" onChange={onFileUpload} />

          {extractedData?.preview && (
            <img src={extractedData.preview} className="rounded-lg max-h-40 object-cover" />
          )}

          {/* FORM INPUTS */}
          <Input label="Bill Name" value={formData.name} onChange={(v)=>setFormData({...formData,name:v})} />
          <Input label="Amount" type="number" value={formData.amount} onChange={(v)=>setFormData({...formData,amount:v})} />
          <Input label="Due Date" type="date" value={formData.due_date} onChange={(v)=>setFormData({...formData,due_date:v})} />

          <Select label="Status" value={formData.status}
            options={["pending","paid","overdue"]}
            onChange={(v)=>setFormData({...formData,status:v})} />

          <Select label="Category" value={formData.category}
            options={["utilities","rent","insurance","subscription","loan","other"]}
            onChange={(v)=>setFormData({...formData,category:v})} />

          <label className="flex items-center gap-2">
            <input type="checkbox" checked={formData.recurring}
              onChange={(e)=>setFormData({...formData,recurring:e.target.checked})} />
            Recurring Bill
          </label>

          <div className="flex gap-2">
            <button type="button" onClick={close} className="w-1/2 py-2 border rounded-lg">Cancel</button>
            <button type="submit" className="w-1/2 py-2 bg-blue-600 text-white rounded-lg">
              {editingBill ? "Update Bill" : "Add Bill"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// SMALL REUSABLE UI
function Input({ label, value, onChange, type="text" }: any) {
  return (
    <div>
      <label className="block text-sm font-medium">{label}</label>
      <input type={type} value={value} onChange={(e)=>onChange(e.target.value)}
        className="w-full border rounded-lg px-3 py-2" required />
    </div>
  );
}

function Select({ label, value, onChange, options }: any) {
  return (
    <div>
      <label className="block text-sm font-medium">{label}</label>
      <select value={value} onChange={(e)=>onChange(e.target.value)}
        className="w-full border rounded-lg px-3 py-2">
        {options.map((o:string)=><option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );
}
