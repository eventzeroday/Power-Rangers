import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Download, FileText, CheckCircle } from 'lucide-react';

// PDF libraries
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export function ExportData() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);

  /* ================================ CSV EXPORT ================================ */
  const exportToCSV = async (tableName: string, fileName: string) => {
    try {
      setLoading(true);
      setExportSuccess(false);

      const { data, error } = await supabase
        .from(tableName)
        .select('*')
        .eq('user_id', user!.id);

      if (error) throw error;
      if (!data?.length) return alert(`No ${tableName} data to export`);

      const headers = Object.keys(data[0]);

      const csvContent = [
        headers.join(','),
        ...data.map(row =>
          headers
            .map(header => {
              const value = row[header];
              if (value === null || value === undefined) return "";
              const stringValue = String(value);
              return stringValue.includes(',') ? `"${stringValue}"` : stringValue;
            })
            .join(',')
        )
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = fileName;
      link.click();

      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (err) {
      console.error(err);
      alert("Error exporting CSV");
    } finally {
      setLoading(false);
    }
  };

  /* ================================ PDF EXPORT ================================ */
  const exportToPDF = async (tableName: string, filePrefix: string) => {
    try {
      setLoading(true);
      setExportSuccess(false);

      const { data, error } = await supabase
        .from(tableName)
        .select('*')
        .eq('user_id', user!.id);

      if (error) throw error;
      if (!data?.length) return alert(`No ${tableName} data to export`);

      const doc = new jsPDF("landscape", "pt", "a4");
      const timestamp = new Date().toLocaleString();

      // Title
      doc.setFontSize(22);
      doc.text(`${tableName.toUpperCase()} REPORT`, 420, 40, { align: "center" });

      // Timestamp
      doc.setFontSize(10);
      doc.text(`Exported: ${timestamp}`, 40, 60);

      // Column Names Formatting
      const renameMap: Record<string, string> = {
        id: "ID",
        user_id: "User ID",
        title: "Title",
        target_amount: "Target",
        current_amount: "Current",
        deadline: "Deadline",
        category: "Category",
        description: "Description",
        created_at: "Created",
        updated_at: "Updated"
      };

      const allKeys = Object.keys(data[0]);
      const headers = allKeys.map(k => renameMap[k] || k);

      const rows = data.map(row =>
        allKeys.map(key => {
          const value = row[key];
          if (value === null) return "";

          if (key.includes("amount")) return `₹ ${Number(value).toLocaleString()}`;
          if (key.includes("date") || key.includes("_at"))
            return new Date(value).toLocaleDateString();

          return String(value);
        })
      );

      autoTable(doc, {
        head: [headers],
        body: rows,
        startY: 80,
        theme: "grid",
        styles: {
          fontSize: 9,
          halign: "center",
          cellPadding: 5
        },
        headStyles: {
          fillColor: [33, 150, 243],
          textColor: "#fff",
          fontSize: 11,
          fontStyle: "bold"
        },
        alternateRowStyles: {
          fillColor: "#f5f5f5"
        },
        columnStyles: {
          0: { cellWidth: 90 },
          1: { cellWidth: 90 },
          2: { cellWidth: 110 },
          3: { cellWidth: 80 },
          4: { cellWidth: 80 },
          5: { cellWidth: 80 },
          6: { cellWidth: 100 },
          7: { cellWidth: 150 },
          8: { cellWidth: 100 },
          9: { cellWidth: 100 }
        },
        margin: { top: 80, bottom: 30 }
      });

      doc.save(`${filePrefix}_${Date.now()}.pdf`);

      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (err) {
      console.error(err);
      alert("Error exporting PDF");
    } finally {
      setLoading(false);
    }
  };

  /* ================================ EXPORT ALL (JSON) ================================ */
  const exportAllData = async () => {
    try {
      setLoading(true);

      const [goalsRes, transactionsRes, billsRes, investmentsRes] = await Promise.all([
        supabase.from('goals').select('*').eq('user_id', user!.id),
        supabase.from('transactions').select('*').eq('user_id', user!.id),
        supabase.from('bills').select('*').eq('user_id', user!.id),
        supabase.from('investments').select('*').eq('user_id', user!.id),
      ]);

      const allData = {
        goals: goalsRes.data || [],
        transactions: transactionsRes.data || [],
        bills: billsRes.data || [],
        investments: investmentsRes.data || [],
        exported_at: new Date().toISOString(),
      };

      const blob = new Blob([JSON.stringify(allData, null, 2)], {
        type: 'application/json;charset=utf-8;'
      });

      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `financeai_all_data_${Date.now()}.json`;
      link.click();

      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (err) {
      console.error(err);
      alert("Error exporting backup");
    } finally {
      setLoading(false);
    }
  };

  /* ================================ EXPORT CARD UI ================================ */
  const ExportCard = ({
    title,
    description,
    onCSV,
    onPDF
  }: any) => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start gap-4">
        <div className="p-3 bg-blue-100 rounded-lg">
          <FileText size={24} className="text-blue-600" />
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
          <p className="text-sm text-gray-600 mb-4">{description}</p>

          <div className="flex gap-2">
            <button
              onClick={onCSV}
              disabled={loading}
              className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg disabled:opacity-50"
            >
              CSV
            </button>

            <button
              onClick={onPDF}
              disabled={loading}
              className="px-4 py-2 bg-red-600 text-white rounded-lg disabled:opacity-50"
            >
              PDF
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  /* ================================ PAGE UI ================================ */
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-2">Export Data</h1>
      <p className="text-gray-600 mb-6">Download your financial data for analysis or backup.</p>

      {exportSuccess && (
        <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
          <CheckCircle size={20} className="text-green-600" />
          <span className="text-green-800 font-medium">Data exported successfully!</span>
        </div>
      )}

      <div className="space-y-6">
        <ExportCard
          title="Goals"
          description="Investment goals and targets."
          onCSV={() => exportToCSV("goals", `goals_${Date.now()}.csv`)}
          onPDF={() => exportToPDF("goals", `goals`)}
        />

        <ExportCard
          title="Transactions"
          description="Income and expenses record."
          onCSV={() => exportToCSV("transactions", `transactions_${Date.now()}.csv`)}
          onPDF={() => exportToPDF("transactions", `transactions`)}
        />

        <ExportCard
          title="Bills"
          description="Bills and payment reminders."
          onCSV={() => exportToCSV("bills", `bills_${Date.now()}.csv`)}
          onPDF={() => exportToPDF("bills", `bills`)}
        />

        <ExportCard
          title="Investments"
          description="Portfolio investments summary."
          onCSV={() => exportToCSV("investments", `investments_${Date.now()}.csv`)}
          onPDF={() => exportToPDF("investments", `investments`)}
        />

        <div className="bg-indigo-600 text-white rounded-xl p-6">
          <h3 className="text-xl font-bold mb-2">Export All Data</h3>
          <p className="mb-4 text-indigo-100">Download complete backup as JSON</p>
          <button
            onClick={exportAllData}
            disabled={loading}
            className="px-4 py-2 bg-white text-indigo-600 rounded-lg font-medium disabled:opacity-50"
          >
            Export Backup JSON
          </button>
        </div>
      </div>
    </div>
  );
}
