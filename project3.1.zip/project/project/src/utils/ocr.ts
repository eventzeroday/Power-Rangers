import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(import.meta.env.VITE_GEMINI_API_KEY);

export async function extractBillData(file: File) {
  const reader = new FileReader();

  return new Promise((resolve) => {
    reader.onload = async () => {
      const base64 = (reader.result as string).split(",")[1];
      const model = genAI.getGenerativeModel({ model: "gemini-pro-vision" });

      const prompt = `
        Read this bill image. Extract JSON only:
        {
          "bill_name": "...",
          "amount": "...",
          "due_date": "YYYY-MM-DD",
          "category": "rent | insurance | utilities | subscription | other",
          "status": "pending"
        }
      `;

      const result = await model.generateContent([
        prompt,
        { inlineData: { data: base64, mimeType: file.type } }
      ]);

      const text = result.response.text();
      resolve(JSON.parse(text));
    };

    reader.readAsDataURL(file);
  });
}
